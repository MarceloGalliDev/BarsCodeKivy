**********************************************************************************
``matplotlib.backends.backend_gtk3agg``, ``matplotlib.backends.backend_gtk3cairo``
**********************************************************************************

**NOTE** These :ref:`backends` are not documented here, to avoid adding a
dependency to building the docs.

.. redirect-from:: /api/backend_gtk3agg_api
.. redirect-from:: /api/backend_gtk3cairo_api

.. module:: matplotlib.backends.backend_gtk3
.. module:: matplotlib.backends.backend_gtk3agg
.. module:: matplotlib.backends.backend_gtk3cairo
