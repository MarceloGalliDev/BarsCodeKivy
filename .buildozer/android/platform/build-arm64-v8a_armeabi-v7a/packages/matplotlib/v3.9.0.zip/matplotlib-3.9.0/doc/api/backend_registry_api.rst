********************************
``matplotlib.backends.registry``
********************************

.. automodule:: matplotlib.backends.registry
   :members:
   :undoc-members:
   :show-inheritance:
