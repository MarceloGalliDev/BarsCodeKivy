:mod:`{{module}}`.{{objname}}
{{ underline }}====================

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

.. minigallery:: {{module}}.{{objname}}
   :add-heading:
