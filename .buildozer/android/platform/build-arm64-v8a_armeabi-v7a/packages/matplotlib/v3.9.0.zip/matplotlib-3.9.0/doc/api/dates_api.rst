********************
``matplotlib.dates``
********************

.. inheritance-diagram:: matplotlib.dates
   :parts: 1
   :top-classes: matplotlib.ticker.Formatter, matplotlib.ticker.Locator

.. automodule:: matplotlib.dates
   :members:
   :undoc-members:
   :exclude-members: rrule
   :show-inheritance:
