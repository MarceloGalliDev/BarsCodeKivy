YAML Schemas for linting and validation
=======================================

Since pre-commit CI doesn't have Internet access, we need to bundle these files
in the repo. The schemas can be updated using `vendor_schemas.py`.
