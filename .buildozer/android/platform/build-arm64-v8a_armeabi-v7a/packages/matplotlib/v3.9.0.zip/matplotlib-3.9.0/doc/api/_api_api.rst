*******************
``matplotlib._api``
*******************

.. automodule:: matplotlib._api
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: matplotlib._api.deprecation
   :members:
   :undoc-members:
   :show-inheritance:
