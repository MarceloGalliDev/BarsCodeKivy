Please refer to the [contributing guide](https://matplotlib.org/devel/index.html).
