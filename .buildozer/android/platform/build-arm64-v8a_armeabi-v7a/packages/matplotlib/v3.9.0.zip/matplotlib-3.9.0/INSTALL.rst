See doc/install/index.rst
