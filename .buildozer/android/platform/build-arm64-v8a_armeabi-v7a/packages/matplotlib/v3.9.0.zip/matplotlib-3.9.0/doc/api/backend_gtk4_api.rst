**********************************************************************************
``matplotlib.backends.backend_gtk4agg``, ``matplotlib.backends.backend_gtk4cairo``
**********************************************************************************

**NOTE** These :ref:`backends` are not documented here, to avoid adding a
dependency to building the docs.

.. redirect-from:: /api/backend_gtk4agg_api
.. redirect-from:: /api/backend_gtk4cairo_api

.. module:: matplotlib.backends.backend_gtk4
.. module:: matplotlib.backends.backend_gtk4agg
.. module:: matplotlib.backends.backend_gtk4cairo
