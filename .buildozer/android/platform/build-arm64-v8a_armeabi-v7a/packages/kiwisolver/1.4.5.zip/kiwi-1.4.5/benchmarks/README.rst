Benchmarks for Kiwi
-------------------

Those benchmarks are mostly used to check the performance of kiwi depending on
different c++ data structure.

# C++

GCC must be installed first on your system (`build-essential` package with apt)

    >>> ./build_and_run_bench.sh

# Python

Running these benchmarks require to install the perf module::

    >>> python enaml_like_benchmarks.py
